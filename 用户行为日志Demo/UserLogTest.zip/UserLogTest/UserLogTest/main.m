//
//  main.m
//  UserLogTest
//
//  Created by Avazu Holding on 2017/11/15.
//  Copyright © 2017年 Avazu Holding. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
	return NSApplicationMain(argc, argv);
}
