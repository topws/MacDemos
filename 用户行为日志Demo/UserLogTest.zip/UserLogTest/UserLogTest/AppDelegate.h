//
//  AppDelegate.h
//  UserLogTest
//
//  Created by Avazu Holding on 2017/11/15.
//  Copyright © 2017年 Avazu Holding. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

