//
//  AppDelegate.m
//  UserLogTest
//
//  Created by Avazu Holding on 2017/11/15.
//  Copyright © 2017年 Avazu Holding. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application
}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
	// Insert code here to tear down your application
}


@end
